#region Using

using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading.Tasks;

#endregion

namespace SmartAdmin.Seed.Services
{
    // This class is used by the application to send email for account confirmation and password reset.
    // For more details see https://go.microsoft.com/fwlink/?LinkID=532713
    public class EmailSender : IEmailSender
    {

        public EmailSender(IOptions<AuthMessageSenderOptions> optionsAccessor)
        {
            Options = optionsAccessor.Value;
        }

        public AuthMessageSenderOptions Options { get; } //set only via Secret Manager

        public Task SendEmailAsync(string email, string subject, string message)
        {
            return Execute(Options.SendGridKey, subject, message, Options.SendGridEmail);
            //return Task.CompletedTask;
        }

        public  async Task<bool> Execute(string apiKey, string subject, string message, string email)
        {
            var client = new SendGridClient(apiKey);
            var msg = new SendGridMessage()
            {
                From = new EmailAddress("waqarkhan2002@gmail.com", "Waqar Khan"),
                Subject = subject,
                PlainTextContent = message,
                HtmlContent = message,
                ReplyTo = new EmailAddress(email)
            };
            msg.AddTo(new EmailAddress("waqarkhan2002@gmail.com"));

            // Disable click tracking.
            // See https://sendgrid.com/docs/User_Guide/Settings/tracking.html
            msg.SetClickTracking(false, false);
            var err= await client.SendEmailAsync(msg);
            return  true;
        }
    }
}
