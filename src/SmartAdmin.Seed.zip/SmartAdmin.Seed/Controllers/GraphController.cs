using System;
using System.Web;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using SmartAdmin.Seed.Data;
using SmartAdmin.Seed.Models;
using static SmartAdmin.Seed.Controllers.ConfirmationController;
using static SmartAdmin.Seed.Controllers.TestController;
using SmartAdmin.Seed.Models.Entities;

namespace SmartAdmin.Seed.Controllers
{
    public class GraphController : Controller
    {





        #region Declaration

        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _env;

        private IList<string> roles;
        int companyid = 0;


        #endregion
        public GraphController(UserManager<ApplicationUser> userManager, ApplicationDbContext context, IWebHostEnvironment env)
        {
            _userManager = userManager;
            _env = env;
            //_signInManager = signInManager;
            //_emailSender = emailSender;
            //_logger = logger;

            _context = context;

        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Settings()
        {
            return View();
        }



        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            var uploads = Path.Combine(_env.WebRootPath, "graph\\stencils\\usman");
            if (file.Length > 0)
            {
                using (var fileStream = new FileStream(Path.Combine(uploads, file.FileName), FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
            }
            return RedirectToAction("Settings");
        }

        public GraphController(UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {


            _userManager = userManager;
            _context = context;




        }

        private async Task<int> GetCompanyId()
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);
            roles = await _userManager.GetRolesAsync(user);
            companyid = user.CompanyId;

            return 0;
        }


        [HttpPost]
        public JsonStringResult GetUploadedIcons()
        {

            var directorypath = Path.Combine(_env.WebRootPath, "graph\\stencils\\usman");

            DirectoryInfo d = new DirectoryInfo(directorypath);
            FileInfo[] Files = d.GetFiles();
            List<FileInformation> lst = new List<FileInformation>();
            foreach (FileInfo file in Files)
            {
                lst.Add(new FileInformation { FileName = file.Name, FileSize = file.Length });
            }

            var json = JsonConvert.SerializeObject(lst);
            return new JsonStringResult(json);
        }





        [HttpPost]
        public JsonStringResult RemoveUploadedIcons(string name)
        {

            var directorypath = Path.Combine(_env.WebRootPath, "graph\\stencils\\usman");

            DirectoryInfo d = new DirectoryInfo(directorypath);
            FileInfo[] Files = d.GetFiles();

            try
            {
                foreach (FileInfo file in Files)
                {
                    if (file.Name == name)
                    {
                        System.IO.File.Delete(file.FullName);
                        break;
                    }
                }

                var json = JsonConvert.SerializeObject("success");
                return new JsonStringResult(json);
            }
            catch (Exception ex)
            {

                var json = JsonConvert.SerializeObject(ex.Message);
                return new JsonStringResult(json);
            }







        }


        [HttpPost]
        public JsonStringResult GetAllIconFiles()
        {

            var directorypath = Path.Combine(_env.WebRootPath, "graph\\stencils\\usman");

            DirectoryInfo d = new DirectoryInfo(directorypath);
            FileInfo[] Files = d.GetFiles();
            List<FileInformation> lst = new List<FileInformation>();
            foreach (FileInfo file in Files)
            {

                lst.Add(new FileInformation { FileName = file.Name, FileSize = file.Length });

            }

            var json = JsonConvert.SerializeObject(lst);
            return new JsonStringResult(json);
        }

        [HttpPost]
        public async Task<JsonStringResult> GetDiagramXML(int FileId)
        {

            try
            {

                var user = await _userManager.GetUserAsync(HttpContext.User);

                var DiagramId = from d in _context.ApplicationDiagram
                                where d.DiagramId == FileId
                                select d;
                FileInformation info = new FileInformation();
                if (DiagramId != null)
                {

                    if (DiagramId.Count() > 0)
                    {

                        info.FileName = DiagramId.FirstOrDefault().DiagramXML;



                    }
                    else
                    {

                    }
                }


                var json = JsonConvert.SerializeObject(info);
                return new JsonStringResult(json);


            }
            catch (Exception)
            {
                FileInformation info = new FileInformation();
                info.FileName = "";
                var json = JsonConvert.SerializeObject(info);
                return new JsonStringResult(json);
            }
        }




        [HttpPost]
        public async Task<JsonStringResult> GetFrameworkData()
        {

            var user = await _userManager.GetUserAsync(HttpContext.User);

            var rolename = GetRole(user.Id);
            if (rolename == "")
                rolename = "admin";

            if (rolename == "admin")
            {

                var result = (from allcountries in _context.lkpCountry

                              select new FrameworkTree
                              {
                                  id = "co" + allcountries.CountryId.ToString(),
                                  text = allcountries.CountryName,
                                  type = "root"


                              }).ToList();

                foreach (var c in result)
                {
                    int id = int.Parse(c.id.Replace("co", ""));
                    c.children = GetStates(id, user.Id, rolename);
                }


                var json = JsonConvert.SerializeObject(result);
                return new JsonStringResult(json);
            }
            else
            {
                var result = (from c in _context.Authorization_AllowedCountries
                              join allcountries in _context.lkpCountry on c.CountryId equals allcountries.CountryId
                              where c.UserId == user.Id
                              select new FrameworkTree
                              {
                                  id = "co" + c.CountryId.ToString(),
                                  text = allcountries.CountryName,
                                  type = "root"


                              }).ToList();

                foreach (var c in result)
                {
                    int id = int.Parse(c.id.Replace("co", ""));
                    c.children = GetStates(id, user.Id, rolename);
                }


                var json = JsonConvert.SerializeObject(result);
                return new JsonStringResult(json);
            }





        }

        private string GetRole(string userId)
        {

            var RoleName = (from ur in _context.UserRoles.AsEnumerable()
                            join r in _context.Roles.AsEnumerable() on ur.RoleId equals r.Id
                            where ur.UserId.ToString() == userId.ToString()
                            select r).ToList();

            if (RoleName != null)
            {
                if (RoleName.Count() > 0)
                {
                    return RoleName.FirstOrDefault().Name.ToLower();
                }
            }

            return "";
        }



        [HttpPost]
        public async Task<JsonStringResult> SaveData(string xml, string fileName, int compid,int updateMode)
        {

            try
            {
                var user = await _userManager.GetUserAsync(HttpContext.User);
                var DiagramId = from d in _context.ApplicationDiagram
                                where d.FileName == fileName && d.CompanyId == compid
                                select d;
                if (updateMode == 0)  //Insert new diagram
                {

                    if (DiagramId != null)
                    {

                        if (DiagramId.Count() > 0)
                        {
                           

                            var jsonRes = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "Diagram with the same name already exists" });
                            return new JsonStringResult(jsonRes);
                        }
                        else
                        {
                            var AppDiagram = new ApplicationDiagram();
                            AppDiagram.ApplicationId = -1;
                            AppDiagram.FileName = fileName;
                            AppDiagram.CompanyId = compid;
                            AppDiagram.DiagramXML = xml;
                            AppDiagram.OwnerId = Guid.Parse(user.Id);
                            _context.ApplicationDiagram.Add(AppDiagram);
                            var dig = await _context.SaveChangesAsync();


                            ApplicationDiagramDetail det = new ApplicationDiagramDetail();
                            det.SharedApplicationId = -1;
                            det.DiagramId = AppDiagram.DiagramId;
                            det.CompanyId = compid;
                            det.SharedWithId = Guid.Parse(user.Id);
                            _context.ApplicationDiagramDetail.Add(det);
                            await _context.SaveChangesAsync();


                            var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "success" });
                            return new JsonStringResult(json);
                        }
                    }
                    var json1 = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "success" });
                    return new JsonStringResult(json1);

                }
                else  //Update existing diagram
                {
                    if (DiagramId != null)
                    {

                        if (DiagramId.Count() > 0)
                        {
                            DiagramId.FirstOrDefault().DiagramXML = xml;
                            await _context.SaveChangesAsync();

                            var jsonRes = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "success" });
                            return new JsonStringResult(jsonRes);
                        }
                      
                    }


                    var json1 = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "success" });
                    return new JsonStringResult(json1);
                }


            }
            catch (Exception ex)
            {
                var userid = Extensions.UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                Extensions.ErrorLogExtension.RecordErrorLogException(ex, "SaveData", "Graph(Index)", userid, _context);

                var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = ex.Message });
                return new JsonStringResult(json);
            }



        }




        private List<FrameworkTree> GetStates(int countryid, string userid, string roleName)
        {
            if (roleName == "country" || roleName == "admin")
            {

                var result = (from allstates in _context.lkpState
                              where allstates.CountryId == countryid
                              select new FrameworkTree
                              {
                                  id = "st" + allstates.StateId.ToString(),
                                  text = allstates.StateName,
                                  type = "root"


                              }).ToList();
                foreach (var c in result)
                {
                    int id = int.Parse(c.id.Replace("st", ""));
                    c.children = GetCities(id, userid, roleName);
                }

                return result;

            }
            else
            {
                var result = (from s in _context.Authorization_AllowedStates
                              join allstates in _context.lkpState on s.StateId equals allstates.StateId
                              where allstates.CountryId == countryid && s.UserId == userid
                              select new FrameworkTree
                              {
                                  id = "st" + s.StateId.ToString(),
                                  text = allstates.StateName,
                                  type = "root"


                              }).ToList();
                foreach (var c in result)
                {
                    int id = int.Parse(c.id.Replace("st", ""));
                    c.children = GetCities(id, userid, roleName);
                }

                return result;
            }
        }

        private List<FrameworkTree> GetCities(int stateid, string userid, string roleName)
        {


            if (roleName == "admin" || roleName == "country")
            {
                var result = (from allcities in _context.lkpCity
                              where allcities.StateId == stateid
                              select new FrameworkTree
                              {
                                  id = "ci" + allcities.CityId.ToString(),
                                  text = allcities.CityName,
                                  type = "root"


                              }).ToList();

                foreach (var d in result)
                {
                    int id = int.Parse(d.id.Replace("ci", ""));
                    d.children = GetDataCenter(id, userid, roleName);
                }


                return result;
            }
            else
            {
                var result = (from s in _context.Authorization_AllowedCities
                              join allcities in _context.lkpCity on s.CityId equals allcities.CityId
                              where allcities.StateId == stateid && s.UserId == userid
                              select new FrameworkTree
                              {
                                  id = "ci" + s.CityId.ToString(),
                                  text = allcities.CityName,
                                  type = "root"


                              }).ToList();

                foreach (var d in result)
                {
                    int id = int.Parse(d.id.Replace("ci", ""));
                    d.children = GetDataCenter(id, userid, roleName);
                }


                return result;
            }
        }

        private List<FrameworkTree> GetDataCenter(int cityid, string userid, string roleName)
        {
            if (roleName == "admin" || roleName == "country")
            {
                var result = (
                              from alldatacenters in _context.lkpDataCenter
                              where alldatacenters.CityId == cityid
                              select new FrameworkTree
                              {
                                  id = "dc" + alldatacenters.DataCenterId.ToString(),
                                  text = alldatacenters.DataCenterName,
                                  type = "root",



                              }).ToList();

                foreach (var de in result)
                {
                    int id = int.Parse(de.id.Replace("dc", ""));
                    de.children = GetDepartment(id, userid, roleName);
                }

                return result;
            }
            else
            {
                var result = (from s in _context.Authorization_AllowedDatacenters
                              join alldatacenters in _context.lkpDataCenter on s.DatacenterId equals alldatacenters.DataCenterId
                              where alldatacenters.CityId == cityid && s.UserId == userid
                              select new FrameworkTree
                              {
                                  id = "dc" + s.DatacenterId.ToString(),
                                  text = alldatacenters.DataCenterName,
                                  type = "root",



                              }).ToList();

                foreach (var de in result)
                {
                    int id = int.Parse(de.id.Replace("dc", ""));
                    de.children = GetDepartment(id, userid, roleName);
                }

                return result;
            }
        }

        public IActionResult mxgraph()
        {
            return View();
        }

        [HttpPost]
        public JsonResult SaveGraph([FromBody] EditorUIXML xml)
        {

            //            Dim xmlSource As String = "<xml><item>1</item><xml><item>2</item><xml><item>3</item></xml>"
            //Dim xmlDoc As New XmlDocument
            //xmlDoc.LoadXml(xmlSource)


            using (FileStream fileStream = new FileStream("file.xml", FileMode.Create))
            {

                XmlWriterSettings settings = new XmlWriterSettings() { Indent = true };
                XmlWriter writer = XmlWriter.Create(fileStream, settings);
                writer.WriteRaw(xml.XMLData);
                writer.Flush();
                fileStream.Flush();
            }
            return Json("Success");
        }

        private List<FrameworkTree> GetDepartment(int datacenterid, string userid, string roleName)
        {
            if (roleName == "admin" || roleName == "country" || roleName == "datacenter")
            {
                var result = (from alldepts in _context.lkpDepartment
                              where alldepts.DataCenterId == datacenterid
                              select new FrameworkTree
                              {
                                  id = "de" + alldepts.DepartmentId.ToString(),
                                  text = alldepts.DepartmentName,
                                  type = "dept"


                              }).ToList();


                foreach (var de in result)
                {
                    int id = int.Parse(de.id.Replace("de", ""));
                    de.children = GetApplicationForDepartment(id, userid, roleName);
                }

                return result;
            }
            else
            {
                var result = (from s in _context.Authorization_AllowedDepartments
                              join alldepts in _context.lkpDepartment on s.DepartmentId equals alldepts.DepartmentId
                              where alldepts.DataCenterId == datacenterid && s.UserId == userid
                              select new FrameworkTree
                              {
                                  id = "de" + s.DepartmentId.ToString(),
                                  text = alldepts.DepartmentName,
                                  type = "dept"


                              }).ToList();


                foreach (var de in result)
                {
                    int id = int.Parse(de.id.Replace("de", ""));
                    de.children = GetApplicationForDepartment(id, userid, roleName);
                }

                return result;
            }
        }



        [HttpPost]
        public List<FrameworkTree> GetApplicationForDepartment(int departmentId, string userid, string roleName)
        {

            try
            {

                if (roleName == "admin" || roleName == "country" || roleName == "datacenter" || roleName == "department")
                {

                    var result = (from a in _context.lkpApplication.AsEnumerable()
                                  join d in _context.lkpDepartment on a.DepartmentId equals d.DepartmentId
                                  where d.DepartmentId == departmentId
                                  select new FrameworkTree
                                  {
                                      id = "ap" + a.ApplicationId.ToString(),
                                      text = a.ApplicationName,
                                      type = "app"


                                  }).ToList();


                    foreach (var ap in result)
                    {
                        int id = int.Parse(ap.id.Replace("ap", ""));
                        ap.children = GetDiagramForApplication(id, userid);
                    }



                    return result;

                }
                else
                {
                    var result = (from d in _context.lkpDepartment.AsEnumerable()
                                  join a in _context.lkpApplication.AsEnumerable() on d.DepartmentId equals a.DepartmentId into ps
                                  from p in ps.AsEnumerable().DefaultIfEmpty()
                                  where d.DepartmentId == departmentId && p.ApplicationName != null
                                  select new FrameworkTree
                                  {
                                      id = "ap" + p.ApplicationId.ToString(),
                                      text = p.ApplicationName,
                                      type = "app"


                                  }).ToList();


                    foreach (var ap in result)
                    {
                        int id = int.Parse(ap.id.Replace("ap", ""));
                        ap.children = GetDiagramForApplication(id, userid);
                    }



                    return result;
                }


            }

            catch (Exception)
            {
                //var userid = UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                //ErrorLogExtension.RecordErrorLogException(ex, "GetDepartmentForDataCenter", "Home", userid, _context);
                return null;
            }
        }

        public List<FrameworkTree> GetDiagramForApplication(int applicationId, string userid)
        {

            try
            {
                var result = (from d in _context.ApplicationDiagramDetail.AsEnumerable()
                              join m in _context.ApplicationDiagram on d.DiagramId equals m.DiagramId
                              where d.SharedApplicationId == applicationId && d.SharedWithId == Guid.Parse(userid)
                              select new FrameworkTree
                              {
                                  id = "diag" + d.DiagramId.ToString(),
                                  text = m.FileName.Replace(".xml", ""),
                                  type = "tree"


                              }).ToList();





                return result;


            }

            catch (Exception)
            {
                //var userid = UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                //ErrorLogExtension.RecordErrorLogException(ex, "GetDepartmentForDataCenter", "Home", userid, _context);
                return null;
            }
        }


        [HttpPost]
        public async Task<JsonStringResult> SaveDiagramDetail(string appId, string FileName, int compid)
        {

            try
            {
                FileName = FileName + ".xml";
                appId = appId.Replace("ap", "");
                int application_id = int.Parse(appId);
                var DiagramId = from d in _context.ApplicationDiagram
                                where d.FileName == FileName && d.CompanyId == compid
                                select d;

                if (DiagramId != null)
                {

                    if (DiagramId.Count() > 0)
                    {
                        var user = await _userManager.GetUserAsync(HttpContext.User);
                        Guid userid = Guid.Parse(user.Id);
                        var ApplicationDetail = from d in _context.ApplicationDiagramDetail
                                                where d.DiagramId == DiagramId.FirstOrDefault().DiagramId && d.SharedWithId == userid && d.CompanyId == compid
                                                select d;

                        if (application_id != -1)     // actual drag drop operation completed
                        {
                            if (ApplicationDetail == null || ApplicationDetail.Count() == 0)
                            {
                                ApplicationDiagramDetail det = new ApplicationDiagramDetail();
                                det.SharedApplicationId = application_id;
                                det.DiagramId = DiagramId.FirstOrDefault().DiagramId;
                                det.CompanyId = compid;
                                det.SharedWithId = DiagramId.FirstOrDefault().OwnerId;
                                _context.ApplicationDiagramDetail.Add(det);
                                await _context.SaveChangesAsync();
                            }
                            else
                            {
                                ApplicationDetail.FirstOrDefault().SharedApplicationId = application_id;
                                await _context.SaveChangesAsync();
                                //ApplicationDetail.FirstOrDefault().DiagramId = DiagramId.FirstOrDefault().DiagramId;
                                //ApplicationDetail.FirstOrDefault().SharedWithId = userid;
                            }
                        }
                        else     //Move application back to main application tree by making it -1
                        {
                            ApplicationDetail.FirstOrDefault().SharedApplicationId = -1;
                            await _context.SaveChangesAsync();
                        }
                    }

                }
                else
                {

                }

                var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "success" });
                return new JsonStringResult(json);


            }

            catch (Exception ex)
            {

                var userid = Extensions.UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                Extensions.ErrorLogExtension.RecordErrorLogException(ex, "SaveDiagramDetail", "Graph(Index)", userid, _context);


                var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = ex.Message });
                return new JsonStringResult(json);
            }
        }


        [HttpPost]
        public async Task<JsonStringResult> DeleteDiagramDetail(string FileName, int compid)
        {

            try
            {
                var user = await _userManager.GetUserAsync(HttpContext.User);
                Guid userid = Guid.Parse(user.Id);
                FileName = FileName + ".xml";

                var DiagramId = from d in _context.ApplicationDiagram
                                where d.FileName == FileName && d.OwnerId == userid && d.CompanyId == compid
                                select d;

                if (DiagramId != null)
                {

                    if (DiagramId.Count() > 0)
                    {


                        _context.ApplicationDiagram.Remove(DiagramId.FirstOrDefault());
                        await _context.SaveChangesAsync();
                        var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "Application xml deleted successfully" });
                        return new JsonStringResult(json);

                    }
                    else
                    {
                        var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "Unable to delete XML,Only owner can delete" });
                        return new JsonStringResult(json);
                    }

                }


                var json1 = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "" });
                return new JsonStringResult(json1);


            }

            catch (Exception ex)
            {

                var userid = Extensions.UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                Extensions.ErrorLogExtension.RecordErrorLogException(ex, "DeleteDiagramDetail", "Graph(Index)", userid, _context);


                var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = ex.Message });
                return new JsonStringResult(json);
            }
        }

        [HttpPost]
        public async Task<JsonStringResult> GetAllowedApplication()
        {

            try
            {



                var user = await _userManager.GetUserAsync(HttpContext.User);

                var rolename = GetRole(user.Id);
                if (rolename == "")
                    rolename = "admin";
                if (rolename == "country")
                {
                    var allAllowedDiagrams = (from add in _context.ApplicationDiagramDetail.AsEnumerable()
                                              join ad in _context.ApplicationDiagram.AsEnumerable() on add.DiagramId equals ad.DiagramId
                                              join ac in _context.Authorization_AllowedCountries.AsEnumerable() on add.SharedWithId.ToString() equals ac.UserId.ToString()
                                              where (from alc in _context.Authorization_AllowedCountries.AsEnumerable() where alc.UserId == user.Id select alc.CountryId).Contains(ac.CountryId)
                                              && !(from ad in _context.ApplicationDiagramDetail
                                                      where ad.SharedWithId == Guid.Parse(user.Id) && ad.SharedApplicationId != -1
                                                      select ad.DiagramId)
                      .Contains(ad.DiagramId)
                                              select ad).Distinct();

                    List<ApplicationTreeInGraph> lst = new List<ApplicationTreeInGraph>();



                    foreach (var file in allAllowedDiagrams)
                    {

                        var filename = Path.GetFileNameWithoutExtension(file.FileName);

                        lst.Add(new ApplicationTreeInGraph { id = file.DiagramId.ToString(), text = filename, type = "tree" });


                    }




                    var json = JsonConvert.SerializeObject(lst);
                    return new JsonStringResult(json);

                }

                else if (rolename == "datacenter")
                {
                    var allAllowedDiagrams = (from add in _context.ApplicationDiagramDetail.AsEnumerable()
                                              join ad in _context.ApplicationDiagram.AsEnumerable() on add.DiagramId equals ad.DiagramId
                                              join ac in _context.Authorization_AllowedDatacenters.AsEnumerable() on add.SharedWithId.ToString() equals ac.UserId.ToString()
                                              where (from alc in _context.Authorization_AllowedDatacenters.AsEnumerable() where alc.UserId == user.Id select alc.DatacenterId).Contains(ac.DatacenterId)
                                                  && !(from ad in _context.ApplicationDiagramDetail
                                                       where ad.SharedWithId == Guid.Parse(user.Id) && ad.SharedApplicationId != -1
                                                       select ad.DiagramId)
                      .Contains(ad.DiagramId)
                                              select ad).Distinct();

                    List<ApplicationTreeInGraph> lst = new List<ApplicationTreeInGraph>();



                    foreach (var file in allAllowedDiagrams)
                    {

                        var filename = Path.GetFileNameWithoutExtension(file.FileName);

                        lst.Add(new ApplicationTreeInGraph { id = file.DiagramId.ToString(), text = filename, type = "tree" });


                    }




                    var json = JsonConvert.SerializeObject(lst);
                    return new JsonStringResult(json);

                }

                else if (rolename == "department")
                {
                    var allAllowedDiagrams = (from add in _context.ApplicationDiagramDetail.AsEnumerable()
                                              join ad in _context.ApplicationDiagram.AsEnumerable() on add.DiagramId equals ad.DiagramId
                                              join ac in _context.Authorization_AllowedDepartments.AsEnumerable() on add.SharedWithId.ToString() equals ac.UserId.ToString()
                                              where (from alc in _context.Authorization_AllowedDepartments.AsEnumerable() where alc.UserId == user.Id select alc.DepartmentId).Contains(ac.DepartmentId)
                                                  && !(from ad in _context.ApplicationDiagramDetail
                                                       where ad.SharedWithId == Guid.Parse(user.Id) && ad.SharedApplicationId != -1
                                                       select ad.DiagramId)
                      .Contains(ad.DiagramId)
                                              select ad).Distinct();

                    List<ApplicationTreeInGraph> lst = new List<ApplicationTreeInGraph>();



                    foreach (var file in allAllowedDiagrams)
                    {

                        var filename = Path.GetFileNameWithoutExtension(file.FileName);

                        lst.Add(new ApplicationTreeInGraph { id = file.DiagramId.ToString(), text = filename, type = "tree" });


                    }




                    var json = JsonConvert.SerializeObject(lst);
                    return new JsonStringResult(json);

                }

                else if (rolename == "application")
                {
                    var allAllowedDiagrams = (from add in _context.ApplicationDiagramDetail.AsEnumerable()
                                              join ad in _context.ApplicationDiagram.AsEnumerable() on add.DiagramId equals ad.DiagramId
                                              join ac in _context.Authorization_AllowedApplications.AsEnumerable() on add.SharedWithId.ToString() equals ac.UserId.ToString()
                                              where (from alc in _context.Authorization_AllowedApplications.AsEnumerable() where alc.UserId == user.Id select alc.ApplicationId).Contains(ac.ApplicationId)
                                                  && !(from ad in _context.ApplicationDiagramDetail
                                                       where ad.SharedWithId == Guid.Parse(user.Id) && ad.SharedApplicationId != -1
                                                       select ad.DiagramId)
                      .Contains(ad.DiagramId)
                                              select ad).Distinct();

                    List<ApplicationTreeInGraph> lst = new List<ApplicationTreeInGraph>();



                    foreach (var file in allAllowedDiagrams)
                    {

                        var filename = Path.GetFileNameWithoutExtension(file.FileName);

                        lst.Add(new ApplicationTreeInGraph { id = file.DiagramId.ToString(), text = filename, type = "tree" });


                    }




                    var json = JsonConvert.SerializeObject(lst);
                    return new JsonStringResult(json);

                }

                else
                {
                    var allAllowedDiagrams =    from d in _context.ApplicationDiagram
                        where !(from ad in _context.ApplicationDiagramDetail
                        where ad.SharedWithId == Guid.Parse(user.Id) && ad.SharedApplicationId != -1
                        select ad.DiagramId)
                        .Contains(d.DiagramId)
                        select d;

                    List<ApplicationTreeInGraph> lst = new List<ApplicationTreeInGraph>();



                    foreach (var file in allAllowedDiagrams)
                    {

                        var filename = Path.GetFileNameWithoutExtension(file.FileName);

                        lst.Add(new ApplicationTreeInGraph { id = file.DiagramId.ToString(), text = filename, type = "tree" });


                    }




                    var json = JsonConvert.SerializeObject(lst);
                    return new JsonStringResult(json);

                }

                //var allAllowedDiagrams = from d in _context.ApplicationDiagram
                //                         where d.OwnerId == Guid.Parse( user.Id)
                //                         select d;





                //var dirPath = Path.Combine(_env.WebRootPath, "App_Users\\" + user.UserName);


                //var files = Directory.GetFiles(dirPath, "*.xml", SearchOption.TopDirectoryOnly);




            }

            catch (Exception ex)
            {
                var g = ex;
                //var userid = UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                //ErrorLogExtension.RecordErrorLogException(ex, "GetDepartmentForDataCenter", "Home", userid, _context);
                return new JsonStringResult("[]");
            }
        }



        [HttpPost]
        public JsonStringResult GetAlreadySharedUsers(int compid, string FileName)
        {

            try
            {
                FileName = FileName + ".xml";



                var result = (from m in _context.ApplicationDiagram
                              join d in _context.ApplicationDiagramDetail on m.DiagramId equals d.DiagramId
                              where m.FileName == FileName
                              select new { d.SharedWithId }).ToList();



                var json = JsonConvert.SerializeObject(result);
                return new JsonStringResult(json);


            }

            catch (Exception ex)
            {
                var userid = Extensions.UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                Extensions.ErrorLogExtension.RecordErrorLogException(ex, "GetAlreadySharedUsers", "Graph(Index)", userid, _context);
                return new JsonStringResult("[]");

            }
        }

        [HttpPost]
        public JsonStringResult GetSharingUsers(int compid)
        {

            try
            {




                var result = (from f in _context.Users
                                  //  join allcountries in countries on c.CountryName equals allcountries.CountryName
                              join u in _context.UserRoles on f.Id equals u.UserId
                              join r in _context.Roles on u.RoleId equals r.Id
                              where f.CompanyId == compid
                              select new { r.Name, u.RoleId, f.Id, f.NormalizedUserName, f.UserName }).ToList();



                var json = JsonConvert.SerializeObject(result);
                return new JsonStringResult(json);


            }

            catch (Exception)
            {

                return new JsonStringResult("[]");
            }
        }

        [HttpPost]
        public async Task<JsonStringResult> SaveUserSharing(string all_usernames, string FileName, int compid, string AlreadyCheckedIds)
        {

            try
            {

                string[] objs = JsonConvert.DeserializeObject<string[]>(all_usernames);
                string[] existingIds = JsonConvert.DeserializeObject<string[]>(AlreadyCheckedIds);

                List<String> idsToRemove = new List<string>();
                foreach (string id in existingIds)
                {
                    if (!objs.Contains(id))
                    {
                        idsToRemove.Add(id);
                    }
                }

                FileName = FileName + ".xml";

                var ActualDiagramId = from d in _context.ApplicationDiagram where d.FileName == FileName select d;

                if (ActualDiagramId.Count() == 0)
                {
                    var jsonDiagram = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "Please select valid diagram for sharing" });
                    return new JsonStringResult(jsonDiagram);
                }

                else
                {
                    foreach (var usr in objs)
                    {






                        var DiagramId = from d in _context.ApplicationDiagramDetail
                                        join m in _context.ApplicationDiagram on d.DiagramId equals m.DiagramId
                                        where m.FileName == FileName && d.SharedWithId == Guid.Parse(usr)
                                        select d;

                        if (DiagramId != null)
                        {

                            if (DiagramId.Count() == 0)
                            {



                                ApplicationDiagramDetail det = new ApplicationDiagramDetail();
                                det.SharedApplicationId = -1;
                                det.CompanyId = compid;
                                det.DiagramId = ActualDiagramId.FirstOrDefault().DiagramId;
                                det.SharedWithId = Guid.Parse(usr);
                                _context.ApplicationDiagramDetail.Add(det);


                            }
                            else
                            {


                            }

                        }


                    }
                }

                foreach (var id in idsToRemove)
                {
                    var appdetail = from a in _context.ApplicationDiagramDetail where a.DiagramId == ActualDiagramId.FirstOrDefault().DiagramId && a.SharedWithId == Guid.Parse(id) select a;
                    if (appdetail.Count() > 0)
                        _context.ApplicationDiagramDetail.Remove(appdetail.FirstOrDefault());
                }


                await _context.SaveChangesAsync();

                var json1 = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "Diagram shared successfully" });
                return new JsonStringResult(json1);


            }

            catch (Exception ex)
            {

                var userid = Extensions.UserExtension.GetUserId(_userManager, HttpContext).GetAwaiter().GetResult();
                Extensions.ErrorLogExtension.RecordErrorLogException(ex, "SaveUserSharing", "Graph(Index)", userid, _context);


                var json = JsonConvert.SerializeObject(new GeneralStringReturn { Message = "Unable to complete diagram sharing" });
                return new JsonStringResult(json);
            }
        }




        public IActionResult GetPartial()
        {
            List<string> countries = new List<string>();
            countries.Add("USA");
            countries.Add("UK");
            countries.Add("India");

            return PartialView("TempPartial", countries);
        }



        //var jsonData = [
        //                                    {
        //                                        id: 1,
        //                                      text: "Folder 1",
        //                                      type: "root",
        //                                      state: {

        //                                          selected: false
        //                                        },
        //                                        children: [
        //                                            {
        //                                                id: 2,
        //                                                text: "Sub Folder 1",
        //                                                type: "child",
        //                                                state: {
        //                                                    selected: false
        //                                                },
        //                                            },
        //                                            {
        //                                                id: 3,
        //                                                text: "Sub Folder 2",
        //                                                type: "child",
        //                                                state: {
        //                                                    selected: false
        //                                                },
        //                                            }
        //                                        ]
        //                                    },
        //                                    {
        //                                        id: 4,
        //                                        text: "Folder 2",
        //                                        type: "root",
        //                                        state: {
        //                                            selected: true
        //                                        },
        //                                        children: []
        //                                    }
        //                                ];
    }

    public class FrameworkTree
    {

        public string id { get; set; }
        public string text { get; set; }
        public string type { get; set; }
        public string state { get; set; }
        public List<FrameworkTree> children { get; set; }

        public FrameworkTree()
        {
            this.children = new List<FrameworkTree>();
        }
    }

    public class EditorUIXML
    {

        public string XMLData { get; set; }

    }

    public class FileInformation
    {

        public string FileName { get; set; }
        public long FileSize { get; set; }


    }


}
