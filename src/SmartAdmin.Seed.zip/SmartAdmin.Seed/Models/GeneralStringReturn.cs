using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartAdmin.Seed.Models
{
    public class GeneralStringReturn
    {
        public string Message { get; set; }
    }
}
