using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartAdmin.Seed.Models.Entities
{
    public class MulitpleModels   {
        

        
            public Databases databases { get; set; }
            public Document document { get; set; }
        public Framework_Databases_Location DatabaseLocation { get; set; }
    }
}
